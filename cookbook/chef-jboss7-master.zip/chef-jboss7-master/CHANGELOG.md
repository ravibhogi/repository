# 0.1.0

Initial release of jboss7

* Enhancements
  * an enhancement

* Bug Fixes
  * a bug fix
